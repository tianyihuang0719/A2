package tests;

import static org.junit.jupiter.api.Assertions.*;

import java.awt.Color;
import java.awt.geom.Point2D;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import model.Circle;

class CircleTest {
    
    private Circle myCircle; // Circle instance for testing
    private static final double TOLERANCE = 1e-6; // Tolerance for comparing floating-point values
    
    /**
     * Sets up a default Circle instance before each test. This method is called
     * before each test is executed to ensure the tests are isolated and have a fresh
     * instance of the circle.
     */

    @BeforeEach
    void setUp() {
        // Initialize a default circle before each test
        myCircle = new Circle();
    }
    
    /**
     * Tests the parameterized constructor with valid inputs.
     * Ensures that the created Circle object has the expected radius, center, and color.
     */
    @Test
    void testCircleDoublePoint2DColor() {
        final Point2D center = new Point2D.Double(2.0, 3.0);
        final Color color = Color.BLUE;
        final double radius = 4.0;

        final Circle circle = new Circle(radius, center, color);

        assertEquals(radius, circle.getRadius(), 1e-6);
        assertEquals(center, circle.getCenter());
        assertEquals(color, circle.getColor());
    }
    
    /**
     * Tests the default constructor.
     * Validates that the default circle has a radius of 1.0, center at (0.0, 0.0), 
     * and color as black.
     */

    @Test
    void testCircle() {
     // Verify the default values for radius, center, and color
        assertEquals(1.0, myCircle.getRadius(), TOLERANCE);
        assertEquals(new Point2D.Double(0.0, 0.0), myCircle.getCenter());
        assertEquals(Color.BLACK, myCircle.getColor());
    }
    
    /**
     * Tests the setRadius method with both valid and invalid inputs.
     * Ensures that a valid radius is set correctly and that an invalid radius 
     * throws an exception.
     */

    @Test
    void testSetRadius() {
     // Test setting a valid radius
        myCircle.setRadius(10.0);
        assertEquals(10.0, myCircle.getRadius(), TOLERANCE);

        // Test setting an invalid radius, expecting an IllegalArgumentException
        assertThrows(IllegalArgumentException.class, () -> {
            myCircle.setRadius(-5.0);
        });
    }
    
    /**
     * Tests the setCenter method.
     * Verifies that the center is set correctly with a valid point and that a null input 
     * throws an exception.
     */

    @Test
    void testSetCenter() {
        final Point2D newCenter = new Point2D.Double(5.0, 5.0);
        myCircle.setCenter(newCenter);
        assertEquals(newCenter, myCircle.getCenter());

        // Test setting a null center, expecting a NullPointerException
        assertThrows(NullPointerException.class, () -> {
            myCircle.setCenter(null);
        });
    }
    
    /**
     * Tests the setColor method.
     * Ensures that a valid color is set correctly and that a null color throws an exception.
     */

    @Test
    void testSetColor() {
     // Test setting the color
        myCircle.setColor(Color.BLUE);
        assertEquals(Color.BLUE, myCircle.getColor());

        // Test setting a null color, expecting a NullPointerException
        assertThrows(NullPointerException.class, () -> {
            myCircle.setColor(null);
        });
    }
    
    /**
     * Tests the getRadius method.
     * Verifies that the method returns the correct radius after being set.
     */

    @Test
    void testGetRadius() {
     // Verify the default radius
        assertEquals(1.0, myCircle.getRadius(), TOLERANCE);

        // Set a new radius and verify it
        myCircle.setRadius(3.0);
        assertEquals(3.0, myCircle.getRadius(), TOLERANCE);
    }
    
    /**
     * Tests the getCenter method.
     * Ensures that the center point returned is correct after being set.
     */

    @Test
    void testGetCenter() {
     // Verify the default center
        assertEquals(new Point2D.Double(0.0, 0.0), myCircle.getCenter());

        // Set a new center and verify it
        final Point2D newCenter = new Point2D.Double(2.0, 3.0);
        myCircle.setCenter(newCenter);
        assertEquals(newCenter, myCircle.getCenter());
    }
    
    /**
     * Tests the getColor method.
     * Ensures that the method returns the correct color after being set.
     */

    @Test
    void testGetColor() {
        // Verify the default color
        assertEquals(Color.BLACK, myCircle.getColor());

        // Set a new color and verify it
        myCircle.setColor(Color.GREEN);
        assertEquals(Color.GREEN, myCircle.getColor());
    }
    
    /**
     * Tests the calculateDiameter method.
     * Verifies that the method returns the correct diameter based on the radius.
     */

    @Test
    void testCalculateDiameter() {
        // Set the radius and verify the diameter
        myCircle.setRadius(4.0);
        assertEquals(8.0, myCircle.calculateDiameter(), TOLERANCE);
    }
    
    /**
     * Tests the calculateCircumference method.
     * Verifies that the method returns the correct circumference based on the radius.
     */

    @Test
    void testCalculateCircumference() {
        // Set the radius and verify the circumference
        myCircle.setRadius(5.0);
        assertEquals(2 * Math.PI * 5.0, myCircle.calculateCircumference(), TOLERANCE);
    }
    
    /**
     * Tests the calculateArea method.
     * Verifies that the method returns the correct area based on the radius.
     */

    @Test
    void testCalculateArea() {
        // Set the radius and verify the area
        myCircle.setRadius(5.0);
        assertEquals(Math.PI * Math.pow(5.0, 2.0), myCircle.calculateArea(), TOLERANCE);
    }
    
    /**
     * Tests the toString method.
     * Verifies that the method returns a string representation matching the expected format.
     */

    @Test
    void testToString() {
        final Point2D center = new Point2D.Double(3.0, 4.0);
        final Circle customCircle = new Circle(5.0, center, Color.RED);

        // Expected string format for the circle
        final String expected = "Circle [radius=5.00, center=" + center + ", color=" + Color.RED + "]";
        assertEquals(expected, customCircle.toString());
    }

}
